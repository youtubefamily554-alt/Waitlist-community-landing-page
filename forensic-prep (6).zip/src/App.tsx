/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState } from 'react';
import ReactGA from 'react-ga4';
import { Nav } from './components/Nav';
import { Marquee } from './components/Marquee';
import { Hero } from './components/Hero';
import { PullQuote } from './components/PullQuote';
import { Features } from './components/Features';
import { KnowledgeMap } from './components/KnowledgeMap';
import { Audience } from './components/Audience';
import { SelectionBlock } from './components/SelectionBlock';
import { Waitlist } from './components/Waitlist';
import { Footer } from './components/Footer';
import { Refer } from './components/Refer';

export default function App() {
  const [hash, setHash] = useState(window.location.hash);

  useEffect(() => {
    const onHashChange = () => {
      setHash(window.location.hash);
      const gaMeasurementId = import.meta.env.VITE_GA_MEASUREMENT_ID;
      if (gaMeasurementId) {
        ReactGA.send({ hitType: 'pageview', page: window.location.pathname + window.location.search + window.location.hash });
      }
    };
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  const isReferPage = hash === '#refer';

  return (
    <div className="min-h-screen bg-bg text-fg selection:bg-brand selection:text-[#0A0A0A] font-sans">
      <Nav />
      {isReferPage ? (
        <Refer />
      ) : (
        <>
          <Marquee />
          <main>
            <Hero />
            <PullQuote />
            <Features />
            <KnowledgeMap />
            <Audience />
            <SelectionBlock />
            <Waitlist />
          </main>
        </>
      )}
      <Footer />
    </div>
  );
}

