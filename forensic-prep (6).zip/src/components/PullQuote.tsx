import { motion } from 'motion/react';

export function PullQuote() {
  return (
    <section className="bg-[#111111] py-16 md:py-20 px-4 sm:px-6 border-y border-[#333333]">
      <div className="max-w-4xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.7 }}
        >
          <div className="w-12 h-1 bg-brand mb-6 md:mb-8" />
          <p className="font-serif text-[clamp(20px,5vw,42px)] leading-snug font-light text-[#EBEAE5] tracking-tight">
            "Imagine a group chat with the sharpest forensic minds in the country.<br/>
            <em className="text-brand/90 italic">Now imagine not being in it.</em>"
          </p>
        </motion.div>
      </div>
    </section>
  );
}
