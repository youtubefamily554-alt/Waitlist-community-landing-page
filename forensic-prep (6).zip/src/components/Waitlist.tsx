import { motion } from 'motion/react';
import { useClickCounter } from '../hooks/useClickCounter';

export function Waitlist() {
  const { count: waitlistCount, recordClick: recordWaitlistClick } = useClickCounter('waitlist_clicks');

  return (
    <section id="waitlist" className="py-16 md:py-32 px-4 sm:px-6 max-w-5xl mx-auto">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="bg-bg-2 p-8 sm:p-12 md:p-20 rounded-3xl border border-rule relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-24 sm:w-32 h-1.5 sm:h-2 bg-brand" />
        
        <div className="absolute top-6 right-6 sm:top-10 sm:right-10 bg-red-600 text-white font-mono text-[10px] sm:text-[11px] font-bold uppercase tracking-widest px-3 py-1.5 rotate-3 shadow-sm border border-red-500/50">
          Invite Only
        </div>
        
        <span className="font-mono text-[10px] sm:text-xs uppercase tracking-widest text-brand/80 mb-4 sm:mb-6 block">
          — The Door is Opening
        </span>
        
        <h2 className="font-serif text-[clamp(28px,6vw,52px)] leading-tight tracking-tight text-fg mb-4 sm:mb-6 max-w-2xl">
          The room opens soon.<br/>
          The <span className="highlight-text font-medium text-[#0A0A0A]">waitlist</span> is open now.
        </h2>
        
        <p className="text-base sm:text-lg text-muted leading-relaxed font-light max-w-xl mb-8 sm:mb-12">
          Be early. The people who get in first will be the ones who shape what this becomes. The door gets harder as the community grows.
        </p>

        <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 max-w-xl">
          <div className="flex flex-col items-start gap-2">
            <a 
              href="#" 
              onClick={(e) => {
                // Not calling preventDefault so they actually can do the form if it was a real form link
                recordWaitlistClick();
              }}
              className="bg-brand text-[#0A0A0A] font-bold px-8 py-4 hover:bg-fg hover:text-bg transition-colors duration-300 rounded-none whitespace-nowrap inline-flex justify-center items-center"
            >
              Join the exclusive waitlist →
            </a>
            {waitlistCount !== null && (
              <span className="text-[11px] sm:text-xs text-muted/80 font-mono flex items-center gap-1.5 pl-2 animate-in fade-in duration-500">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-brand"></span>
                </span>
                {waitlistCount.toLocaleString()} individuals have shown interest
              </span>
            )}
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-rule max-w-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <p className="font-sans text-sm text-fg/80 font-medium mb-1">
              Want to skip the line?
            </p>
            <p className="font-serif text-sm text-muted font-light">
              Refer a peer. Bump your priority.
            </p>
          </div>
          <a 
            href="#refer"
            className="font-mono text-[10px] uppercase tracking-widest text-brand bg-brand/10 border border-brand/30 px-6 py-3 hover:bg-brand hover:text-[#0A0A0A] transition-colors duration-300 font-bold"
          >
            Refer a Friend ↗
          </a>
        </div>

        <p className="mt-6 sm:mt-8 font-mono text-[9px] sm:text-[10px] uppercase tracking-widest text-muted/60">
          Free · Invite-only · Selective always · Yours to earn
        </p>
      </motion.div>
    </section>
  );
}
