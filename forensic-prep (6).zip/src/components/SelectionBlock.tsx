import { motion } from 'motion/react';

export function SelectionBlock() {
  return (
    <section className="py-16 md:py-32 px-4 sm:px-6 bg-[#111111] border-y border-[#333333] relative overflow-hidden">
      {/* Subtle background element */}
      <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-brand/5 to-transparent pointer-events-none" />

      <div className="max-w-4xl mx-auto grid md:grid-cols-2 gap-10 md:gap-16 items-start relative z-10">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
        >
          <span className="font-mono text-[10px] sm:text-xs uppercase tracking-widest text-brand mb-4 sm:mb-6 block">
            — The door
          </span>
          <h2 className="font-serif text-[clamp(36px,6vw,64px)] leading-[1.05] tracking-tight text-[#EBEAE5] mb-4 sm:mb-6">
            Gatekept?<br/>
            <em className="italic font-light text-brand/90">Maybe a little.</em>
          </h2>
          <p className="font-serif text-lg sm:text-xl text-[#EBEAE5]/70 font-light">
            And we make <em className="italic text-[#EBEAE5]">zero apologies</em> for it.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="flex flex-col gap-4 sm:gap-6"
        >
          <p className="text-base sm:text-lg text-[#969691] leading-relaxed font-light">
            We read every single request. We don't care about your marks. Not your college name. Not your attendance record.
          </p>
          <p className="text-base sm:text-lg text-[#EBEAE5]/80 leading-relaxed font-light">
            We only care about <span className="highlight-text font-medium text-[#0A0A0A]">the obsession.</span>
          </p>
          <p className="text-base sm:text-lg text-[#969691] leading-relaxed font-light">
            The ones who get in — show up, go deep, and give back. The ones who don't — weren't ready yet. If you think you're ready, apply.
          </p>
        </motion.div>
      </div>
    </section>
  );
}
