import { motion } from 'motion/react';

const ITEMS = [
  "Case Drops", "Midnight Threads", "Live Debates", "Masterclasses", 
  "AMAs with Scientists", "1:1 Mentorship", "Lab Visits", "Peer Collaborations",
  "City Meetups", "Research Papers", "Competitions", "Office Hours",
  "Inner Circle Sessions", "Field Notes", "The Annual Gathering", "Member Introductions"
];

export function Marquee() {
  return (
    <div className="overflow-hidden border-y border-[#333333] py-4 bg-[#111111] relative flex items-center">
      <motion.div 
        className="flex gap-12 whitespace-nowrap"
        animate={{ x: [0, -1035] }} // Adjust based on content width to create seamless loop
        transition={{ 
          repeat: Infinity, 
          ease: "linear", 
          duration: 20 
        }}
      >
        {/* Render twice for seamless looping */}
        {[...ITEMS, ...ITEMS].map((item, i) => (
          <span key={i} className="font-mono text-[11px] uppercase tracking-widest text-brand font-medium flex items-center gap-4">
            {item}
            <span className="text-brand/40">·</span>
          </span>
        ))}
      </motion.div>
    </div>
  );
}
