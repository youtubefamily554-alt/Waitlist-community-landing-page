import { motion } from 'motion/react';
import crowdBg from '../assets/Crowd.png.png';

export function Hero() {
  return (
    <section className="relative overflow-hidden min-h-[90vh] flex flex-col justify-center py-16 md:py-32 px-4 sm:px-6">
      {/* Background Image Container */}
      <div className="absolute inset-0 z-0 bg-[#111111]">
        <img 
          src={crowdBg} 
          alt="Crowd background"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover opacity-80 mix-blend-luminosity"
        />
        {/* Gradients to blend the image seamlessly into the page background */}
        <div className="absolute inset-0 bg-gradient-to-b from-bg/40 via-bg/80 to-bg" />
        <div className="absolute inset-0 bg-gradient-to-r from-bg via-bg/60 to-transparent" />
      </div>

      <div className="max-w-7xl mx-auto w-full relative z-10">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 md:gap-6 mb-12 md:mb-16 pb-6 md:pb-8 border-b border-rule/50">
          <motion.div 
            initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}
            className="font-mono text-[10px] sm:text-xs uppercase tracking-widest text-muted font-medium"
          >
            — Est. 2026 · New Delhi, India
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.1 }}
            className="font-mono text-[10px] sm:text-xs uppercase tracking-widest text-muted font-medium"
          >
            India's first. The world's only.
          </motion.div>
        </div>

        <div className="max-w-3xl">
          <div>
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.5, delay: 0.2 }}
              className="inline-block mb-6 md:mb-8"
            >
              <span className="font-mono text-[10px] sm:text-[11px] uppercase tracking-widest font-medium bg-brand text-[#0A0A0A] px-3 py-1.5 shadow-lg">
                Closed · Invite-Only · Worldwide
              </span>
            </motion.div>

            <motion.h1 
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.3 }}
              className="font-serif text-[clamp(40px,10vw,96px)] leading-[0.98] tracking-tight font-normal text-fg drop-shadow-md"
            >
              The forensic community<br/>
              <span className="italic font-light text-brand/90">India actually needed.</span>
            </motion.h1>

            <motion.p 
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.4 }}
              className="font-serif text-[clamp(16px,4vw,24px)] leading-relaxed font-light text-fg/80 mt-6 md:mt-8 max-w-2xl drop-shadow-sm"
            >
              Building India's largest space for forensic enthusiasts. No boring lectures. No tourists. Just a <em className="text-fg font-medium">raw, breathing forensic world</em> where the sharpest minds connect, vibe, and actually solve things.
            </motion.p>

            <motion.div 
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.5 }}
              className="mt-8 md:mt-12 flex flex-col sm:flex-row gap-4"
            >
              <a href="#waitlist" className="inline-flex items-center justify-center gap-2 px-6 sm:px-8 py-3 sm:py-4 bg-brand text-[#0A0A0A] font-sans text-sm font-bold tracking-wide border border-brand hover:bg-fg hover:border-fg hover:text-bg transition-all duration-300 w-full sm:w-auto shadow-xl">
                Join the exclusive waitlist →
              </a>
              <a href="#refer" className="inline-flex items-center justify-center gap-2 px-6 sm:px-8 py-3 sm:py-4 bg-transparent text-fg font-sans text-sm font-bold tracking-wide border border-rule/50 hover:border-brand hover:text-brand transition-all duration-300 w-full sm:w-auto backdrop-blur-sm bg-bg/10">
                Refer a Peer ↗
              </a>
            </motion.div>
          </div>
        </div>

        <motion.div 
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1, delay: 0.8 }}
          className="mt-16 md:mt-20 pt-6 md:pt-8 border-t border-rule/50 flex flex-col sm:flex-row flex-wrap gap-4 sm:gap-8"
        >
          {[
            "Invite-only · Applications open now",
            "Free to join · Selective always",
            "India → Worldwide · One room"
          ].map((text, i) => (
            <div key={i} className="flex items-center gap-3">
              <div className="w-1.5 h-1.5 bg-brand rounded-full animate-pulse flex-shrink-0" />
              <span className="font-mono text-[10px] sm:text-xs uppercase tracking-widest text-fg/70">{text}</span>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
