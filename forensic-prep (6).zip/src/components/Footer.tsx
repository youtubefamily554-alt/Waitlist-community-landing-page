import { Logo } from './Logo';

export function Footer() {
  return (
    <footer className="dark bg-[#111111] text-[#EBEAE5] border-t border-[#333333] pt-16 md:pt-20 pb-8 px-4 sm:px-6">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10 md:gap-12 mb-12 md:mb-16">
          <div className="sm:col-span-2 lg:col-span-1">
            <div className="flex items-center gap-3 md:gap-4 mb-4 md:mb-6">
              <Logo />
            </div>
            <p className="text-sm text-[#969691] leading-relaxed max-w-xs font-light">
              India's first closed forensic community. Worldwide. A serious place for the forensic-obsessed — to learn, think, connect, and build careers that matter.
            </p>
          </div>

          <div>
            <h5 className="font-mono text-[10px] uppercase tracking-widest text-[#969691] mb-4 md:mb-6 font-medium">Community</h5>
            <ul className="flex flex-col gap-3 md:gap-4">
              <li>
                <a href="#refer" className="text-sm text-brand font-medium hover:text-[#EBEAE5] transition-colors flex items-center gap-2 group w-fit">
                  Refer a Peer ↗
                </a>
              </li>
              {['Case Drops', 'Masterclasses', '1:1 Mentorship', 'Inner Circle'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-sm text-[#EBEAE5]/80 hover:text-brand transition-colors flex items-center gap-2 group w-fit">
                    {item}
                    <span className="font-mono text-[8px] uppercase tracking-widest text-[#0A0A0A] bg-brand px-1.5 py-0.5 font-bold opacity-80 group-hover:opacity-100 transition-opacity">Soon</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h5 className="font-mono text-[10px] uppercase tracking-widest text-[#969691] mb-4 md:mb-6 font-medium">More</h5>
            <ul className="flex flex-col gap-3 md:gap-4">
              {['Prep Kit', 'Forensic Maniac', 'City Meetups', 'The Journal'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-sm text-[#EBEAE5]/80 hover:text-brand transition-colors flex items-center gap-2 group w-fit">
                    {item}
                    <span className="font-mono text-[8px] uppercase tracking-widest text-[#0A0A0A] bg-brand px-1.5 py-0.5 font-bold opacity-80 group-hover:opacity-100 transition-opacity">Soon</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h5 className="font-mono text-[10px] uppercase tracking-widest text-[#969691] mb-4 md:mb-6 font-medium">Connect</h5>
            <ul className="flex flex-col gap-3 md:gap-4">
              {['Instagram', 'LinkedIn', 'Contact'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-sm text-[#EBEAE5]/80 hover:text-brand transition-colors w-fit block">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-center gap-4 pt-6 md:pt-8 border-t border-[#333333] font-mono text-[9px] md:text-[10px] uppercase tracking-widest text-[#969691]">
          <div className="text-center md:text-left">© 2026 Forensic Prep · Made in India · For the world</div>
          <div className="flex gap-4 md:gap-6">
            <a href="#" className="hover:text-[#EBEAE5] transition-colors">Privacy</a>
            <a href="#" className="hover:text-[#EBEAE5] transition-colors">Terms</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
