import { motion } from 'motion/react';

const FEATURES = [
  { num: "01", when: "Anytime", title: "The Group Chat", desc: "A case drops. The chat ignites. A scientist walks in at midnight and drops pure knowledge. You learn more here than in a whole semester." },
  { num: "02", when: "Never recorded", title: "Secret Sessions", desc: "Real experts. Small rooms. Zero recordings. If you aren't there, you missed it — and that's the whole point." },
  { num: "03", when: "Monthly", title: "Ask Me Anything", desc: "Open hour with working forensic scientists. Ask anything. Get the kind of answers your professor legally couldn't give you." },
  { num: "04", when: "1:1", title: "Direct Access", desc: "Skip the cold emails. Get 45 minutes with someone who actually has the job you want. It changes everything." },
  { num: "05", when: "Practitioners only", title: "The Vault", desc: "Lab directors, court examiners, working scientists. A quiet room the public knows exists but can't see into. The real center of gravity." },
  { num: "06", when: "Collaborative", title: "Side Quests", desc: "Research papers. Case archives. Built together, inside the room, by people who are genuinely obsessed with the field." },
  { num: "07", when: "Real stakes", title: "Proving Grounds", desc: "Case-based challenges. Not a piece of paper — a literal seat at the table. Earned in front of the people who matter." },
  { num: "08", when: "IRL + Annual", title: "IRL Mode", desc: "Delhi. Mumbai. BLR. Small gatherings where the internet becomes real. Plus one annual event that's invite-only." },
];

export function Features() {
  return (
    <section className="py-16 md:py-32 px-4 sm:px-6 max-w-7xl mx-auto">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 md:gap-10 mb-10 md:mb-16 pb-6 md:pb-8 border-b border-rule"
      >
        <div className="flex-1">
          <span className="font-mono text-[10px] sm:text-xs uppercase tracking-widest text-brand mb-3 md:mb-4 block">
            — Inside the room
          </span>
          <h2 className="font-serif text-[clamp(28px,6vw,56px)] leading-none tracking-tight text-fg">
            What's inside?<br/>
            <em className="font-light italic text-brand">The good stuff.</em>
          </h2>
        </div>
        <p className="max-w-sm text-sm sm:text-base text-muted leading-relaxed font-light">
          We built the ultimate playground for forensic nerds. Here's what you get if you make the cut.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 border border-rule">
        {FEATURES.map((feat, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: (i % 4) * 0.1 }}
            className={`p-6 sm:p-8 border-b border-rule ${i % 4 !== 3 ? 'lg:border-r' : ''} ${i % 2 !== 1 ? 'md:border-r' : ''} hover:bg-bg-2 transition-colors duration-300 group`}
          >
            <div className="font-mono text-[10px] text-brand uppercase tracking-widest mb-4 sm:mb-6 flex items-center justify-between">
              <span>{feat.num}</span>
              <span className="text-muted group-hover:text-brand/50 transition-colors">— {feat.when}</span>
            </div>
            <h3 className="font-serif text-lg sm:text-xl font-medium text-fg mb-2 sm:mb-3 leading-tight">{feat.title}</h3>
            <p className="text-sm text-muted leading-relaxed">{feat.desc}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
