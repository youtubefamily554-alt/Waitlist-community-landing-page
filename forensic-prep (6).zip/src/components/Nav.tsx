import { Logo } from './Logo';
import { ThemeToggle } from './ThemeToggle';

export function Nav() {
  return (
    <nav className="sticky top-0 z-50 bg-bg/80 backdrop-blur-md border-b border-rule">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
        <a href="#" className="hover:opacity-80 transition-opacity">
          <Logo />
        </a>
        <div className="flex items-center gap-4">
          <ThemeToggle />
          <span className="hidden sm:inline-block font-mono text-[9px] uppercase tracking-widest text-[#0A0A0A] bg-brand px-2 py-1 font-bold">
            Coming Soon
          </span>
        </div>
      </div>
    </nav>
  );
}
