import { motion } from 'motion/react';
import { 
  Fingerprint, 
  Microscope, 
  TestTube, 
  Dna, 
  Monitor, 
  Brain, 
  Search, 
  FileSearch, 
  Target, 
  ShieldCheck, 
  Activity, 
  Camera, 
  Database, 
  BadgeAlert,
  Bug,
  Calculator,
  UserSearch,
  HardDrive
} from 'lucide-react';

const SPECIALTIES = [
  { label: "Toxicology", icon: TestTube, color: "text-rose-500", bg: "bg-rose-500/10" },
  { label: "DNA & Serology", icon: Dna, color: "text-blue-500", bg: "bg-blue-500/10" },
  { label: "Digital Forensics", icon: HardDrive, color: "text-cyan-500", bg: "bg-cyan-500/10" },
  { label: "Cyber Investigation", icon: ShieldCheck, color: "text-emerald-500", bg: "bg-emerald-500/10" },
  { label: "Ballistics", icon: Target, color: "text-amber-500", bg: "bg-amber-500/10" },
  { label: "Document Exam", icon: FileSearch, color: "text-purple-500", bg: "bg-purple-500/10" },
  { label: "Forensic Psychology", icon: Brain, color: "text-pink-500", bg: "bg-pink-500/10" },
  { label: "Scene Investigation", icon: Search, color: "text-yellow-500", bg: "bg-yellow-500/10" },
  { label: "Forensic Accounting", icon: Calculator, color: "text-green-500", bg: "bg-green-500/10" },
  { label: "Forensic Entomology", icon: Bug, color: "text-lime-500", bg: "bg-lime-500/10" },
  { label: "Criminal Profiling", icon: UserSearch, color: "text-indigo-500", bg: "bg-indigo-500/10" },
  { label: "Trace Evidence", icon: Microscope, color: "text-orange-500", bg: "bg-orange-500/10" },
  { label: "Pattern Analysis", icon: Fingerprint, color: "text-violet-500", bg: "bg-violet-500/10" },
  { label: "Forensic Pathology", icon: Activity, color: "text-red-500", bg: "bg-red-500/10" },
  { label: "Crime Photography", icon: Camera, color: "text-teal-500", bg: "bg-teal-500/10" },
  { label: "Data Recovery", icon: Database, color: "text-sky-500", bg: "bg-sky-500/10" },
  { label: "Forensic Nursing", icon: BadgeAlert, color: "text-fuchsia-500", bg: "bg-fuchsia-500/10" },
  { label: "Mobile Forensics", icon: Monitor, color: "text-indigo-400", bg: "bg-indigo-400/10" },
];

export function KnowledgeMap() {
  return (
    <section className="py-10 md:py-16 px-4 sm:px-6 bg-bg-2 overflow-hidden relative">
      {/* Background glow for the crowd chart */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-brand/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex flex-col items-center text-center gap-4 mb-8 md:mb-12"
        >
          <span className="font-mono text-[10px] sm:text-xs uppercase tracking-widest text-brand block">
            — The Crowd
          </span>
          <h2 className="font-serif text-[clamp(28px,6vw,56px)] leading-none tracking-tight text-fg max-w-3xl">
            One room. <em className="font-light italic text-fg opacity-70">Every discipline.</em>
          </h2>
          <p className="max-w-xl text-sm sm:text-base text-muted leading-relaxed font-light mt-2">
            However deep your specialisation — there is a corner of this room built for it. The most diverse assembly of forensic minds.
          </p>
        </motion.div>

        <div className="relative w-full h-[350px] sm:h-[450px] md:h-[550px] mx-auto max-w-6xl">
          {SPECIALTIES.map((spec, i) => {
            const Icon = spec.icon;
            // Create a varied grid effect for different sizes
            const isLarge = i === 1 || i === 4 || i === 7 || i === 12;
            const isMedium = i === 0 || i === 5 || i === 8 || i === 10 || i === 14;
            
            const positions = [
              { top: "5%", left: "15%" },
              { top: "8%", left: "50%" },
              { top: "12%", left: "85%" },
              { top: "28%", left: "20%" },
              { top: "25%", left: "75%" },
              { top: "42%", left: "10%" },
              { top: "45%", left: "88%" },
              { top: "58%", left: "22%" },
              { top: "62%", left: "82%" },
              { top: "75%", left: "15%" },
              { top: "82%", left: "85%" },
              { top: "90%", left: "50%" },
              { top: "35%", left: "48%" },
              { top: "55%", left: "52%" },
              { top: "72%", left: "45%" },
              { top: "20%", left: "35%" },
              { top: "68%", left: "68%" },
              { top: "85%", left: "28%" },
            ];

            const pos = positions[i] || { top: "50%", left: "50%" };

            const yVal = 10 + (i % 5) * 4;
            const xVal = 5 + (i % 3) * 3;
            const duration = 6 + (i % 4) * 2;
            const delay = (i % 5) * 0.5;

            return (
              <div 
                key={i} 
                className="absolute z-10" 
                style={{ top: pos.top, left: pos.left, transform: 'translate(-50%, -50%)' }}
              >
                <motion.div
                  initial={{ opacity: 0, scale: 0 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true, margin: "50px" }}
                  animate={{ 
                    y: [0, -yVal, 0, yVal, 0],
                    x: [0, xVal, 0, -xVal, 0],
                  }}
                  transition={{ 
                    opacity: { duration: 0.5, delay: i * 0.05 },
                    scale: { duration: 0.5, delay: i * 0.05, type: "spring" },
                    y: { repeat: Infinity, duration, ease: "easeInOut", delay },
                    x: { repeat: Infinity, duration: duration + 1, ease: "easeInOut", delay: delay + 0.5 }
                  }}
                  whileHover={{ scale: 1.1, zIndex: 50 }}
                  className={`flex items-center gap-2 sm:gap-3 md:gap-4 rounded-full border border-rule/50 bg-bg/80 backdrop-blur-md shadow-xl cursor-default transition-colors hover:border-brand/50 hover:shadow-brand/5 hover:bg-bg ${
                    isLarge ? 'px-4 py-2 sm:px-6 sm:py-3' : 
                    isMedium ? 'px-3 py-1.5 sm:px-5 sm:py-2.5' : 
                    'px-2 py-1 sm:px-4 sm:py-2'
                  }`}
                >
                  <div className={`flex items-center justify-center rounded-full ${spec.bg} ${spec.color} ${
                    isLarge ? 'w-8 h-8 sm:w-12 sm:h-12' : 
                    isMedium ? 'w-6 h-6 sm:w-10 sm:h-10' : 
                    'w-5 h-5 sm:w-8 sm:h-8'
                  }`}>
                    <Icon className={
                      isLarge ? 'w-4 h-4 sm:w-6 sm:h-6' : 
                      isMedium ? 'w-3 h-3 sm:w-5 sm:h-5' : 
                      'w-2.5 h-2.5 sm:w-4 sm:h-4'
                    } />
                  </div>
                  <span className={`font-mono uppercase tracking-widest text-fg whitespace-nowrap ${
                    isLarge ? 'text-[10px] sm:text-sm font-semibold' : 
                    isMedium ? 'text-[9px] sm:text-xs font-medium' : 
                    'text-[8px] sm:text-[10px]'
                  }`}>
                    {spec.label}
                  </span>
                </motion.div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
