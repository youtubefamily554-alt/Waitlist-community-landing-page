import { motion } from 'motion/react';

export function Logo({ className = "" }: { className?: string }) {
  return (
    <motion.div 
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className={`inline-flex items-center group ${className}`}
    >
      <img src="/favicon-dark.svg" alt="Forensic Prep Logo" className="h-10 sm:h-12 w-auto object-contain dark:hidden" />
      <img src="/favicon.svg" alt="Forensic Prep Logo" className="h-10 sm:h-12 w-auto object-contain hidden dark:block" />
    </motion.div>
  );
}

export function LogoMark({ className = "" }: { className?: string }) {
  return (
    <motion.div 
      whileHover={{ scale: 1.1 }}
      transition={{ duration: 0.5 }}
      className={`inline-flex items-center justify-center ${className}`}
    >
      <img src="/favicon-dark.svg" alt="Forensic Prep Icon" className="h-10 w-10 object-contain dark:hidden" />
      <img src="/favicon.svg" alt="Forensic Prep Icon" className="h-10 w-10 object-contain hidden dark:block" />
    </motion.div>
  );
}
