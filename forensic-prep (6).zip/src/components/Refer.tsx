import { motion } from 'motion/react';
import { useState } from 'react';
import { useClickCounter } from '../hooks/useClickCounter';

export function Refer() {
  const [copied, setCopied] = useState(false);
  const { count: referCount, recordClick: recordReferClick } = useClickCounter('refer_clicks');

  const handleShare = async () => {
    recordReferClick();
    const textToShare = "The forensic room everyone is talking about. Strictly invite-only. Drop my name to get us both past the door.";
    const urlToShare = window.location.origin;

    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Forensic Prep',
          text: textToShare,
          url: urlToShare,
        });
      } catch (err) {
        if ((err as Error).name !== 'AbortError') {
          fallbackCopy(textToShare, urlToShare);
        }
      }
    } else {
      fallbackCopy(textToShare, urlToShare);
    }
  };

  const fallbackCopy = (text: string, url: string) => {
    navigator.clipboard.writeText(`${text}\n\n${url}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <main className="py-24 md:py-32 px-4 sm:px-6 max-w-4xl mx-auto min-h-[80vh] flex flex-col justify-center">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-bg-2 p-8 sm:p-12 md:p-16 rounded-3xl border border-rule relative overflow-hidden shadow-2xl"
      >
        <div className="absolute top-0 left-0 w-32 h-2 bg-brand" />
        
        <span className="font-mono text-[10px] sm:text-xs uppercase tracking-widest text-brand/80 mb-6 block">
          — Priority Access
        </span>

        <h1 className="font-serif text-[clamp(36px,6vw,64px)] leading-[1.05] tracking-tight text-fg mb-6">
          Skip the line.<br/>
          Bring <em className="italic font-light text-brand/90">the fire.</em>
        </h1>

        <p className="text-lg text-muted leading-relaxed font-light mb-8 max-w-2xl">
          Every verified peer you refer moves your application up the stack. We want the right minds in the room. If you know them, we want you both.
        </p>

        <div className="bg-bg border border-rule p-6 sm:p-8 rounded-xl mb-10">
          <h3 className="font-mono text-xs uppercase tracking-widest text-fg mb-4">How it works</h3>
          <ol className="flex flex-col gap-4 text-sm sm:text-base text-muted font-light list-decimal pl-4">
            <li className="pl-2">Send them the application link.</li>
            <li className="pl-2">Tell them to drop your <strong className="text-fg font-medium">exact Full Name & Email</strong> in the "Referred By" section of their form.</li>
            <li className="pl-2">When they apply, your priority bumps up.</li>
          </ol>
          <div className="mt-6 pt-6 border-t border-rule">
            <p className="font-mono text-[10px] uppercase tracking-widest text-brand/80">
              Strictly no duplicates. No fake entries. Quality over quantity.
            </p>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-4">
          <div className="flex flex-col items-center sm:items-start gap-2 w-full sm:w-auto">
            <button 
              onClick={handleShare}
              className="w-full sm:w-auto bg-brand text-[#0A0A0A] font-bold px-8 py-4 hover:bg-fg hover:text-bg transition-colors duration-300 rounded-none whitespace-nowrap inline-flex justify-center items-center gap-2"
            >
              {copied ? '✓ Link Copied' : 'Share Application Link'}
            </button>
            {referCount !== null && (
              <span className="text-[11px] sm:text-xs text-muted/80 font-mono flex items-center gap-1.5 pl-2 animate-in fade-in duration-500">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-brand"></span>
                </span>
                {referCount.toLocaleString()} peers referred so far
              </span>
            )}
          </div>
          <a 
            href="#" 
            className="text-sm font-mono uppercase tracking-widest text-muted hover:text-fg transition-colors mt-4 sm:mt-0"
          >
            ← Back to Home
          </a>
        </div>
      </motion.div>
    </main>
  );
}
