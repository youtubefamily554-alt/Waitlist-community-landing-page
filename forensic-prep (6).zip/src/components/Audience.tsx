import { motion } from 'motion/react';
import { Shield, Building, MapPin } from 'lucide-react';

const ROW1 = [
  "NFSU", "CFSL", "Ministry of Home Affairs", "John Jay College, NYC", "State FSLs",
  "Panjab University", "CID", "University of Dundee, UK", "Osmania University"
];

const ROW2 = [
  "Dr. Harisingh Gour University", "FBI Laboratory", "NIA", "Amity University", 
  "Interpol", "CBI", "SFSL Mumbai", "AIIMS New Delhi", "Henry C. Lee Institute"
];

const ROW3 = [
  "Delhi Police Cyber Cell", "Michigan State University", "Bundelkhand University", 
  "Met Police, London", "University of Delhi", "NIST", "Chandigarh University", "DRDO"
];

export function Audience() {
  return (
    <section className="py-24 md:py-32 px-4 sm:px-6 relative overflow-hidden bg-bg-2">
      {/* Background elements */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-brand/5 rounded-full blur-[100px] pointer-events-none" />
      
      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center max-w-3xl mx-auto mb-16 md:mb-24"
        >
          <span className="font-mono text-[10px] sm:text-xs uppercase tracking-widest text-brand mb-4 block">
            — The Waitlist
          </span>
          <h2 className="font-serif text-[clamp(28px,5vw,48px)] leading-tight tracking-tight text-fg mb-6">
            Look who's <em className="font-light italic text-brand">already here.</em>
          </h2>
          <p className="text-sm sm:text-base text-muted leading-relaxed font-light">
            Top tier talent from everywhere. They know what's up. Claim your spot before they take all the good seats.
          </p>
        </motion.div>

        <div className="relative">
          {/* Fading edges for the scrolling effect */}
          <div className="absolute inset-y-0 left-0 w-16 sm:w-32 bg-gradient-to-r from-bg-2 to-transparent z-10 pointer-events-none" />
          <div className="absolute inset-y-0 right-0 w-16 sm:w-32 bg-gradient-to-l from-bg-2 to-transparent z-10 pointer-events-none" />
          
          <div className="flex flex-col gap-4 sm:gap-6 overflow-hidden pb-4">
            {/* First Row */}
            <motion.div 
              className="flex gap-4 sm:gap-6 w-max"
              animate={{ x: ["0%", "-50%"] }}
              transition={{ repeat: Infinity, ease: "linear", duration: 30 }}
            >
              {[...ROW1, ...ROW1].map((inst, i) => (
                <div key={i} className="flex items-center gap-3 px-6 py-4 bg-bg border border-rule/50 rounded-full shadow-lg shadow-black/20 hover:border-brand/50 transition-colors cursor-default">
                  <Shield className="w-4 h-4 text-brand/70" />
                  <span className="font-mono text-xs sm:text-sm text-fg/80 uppercase tracking-wide">{inst}</span>
                </div>
              ))}
            </motion.div>

            {/* Second Row (Reverse direction) */}
            <motion.div 
              className="flex gap-4 sm:gap-6 w-max ml-[-100px]"
              animate={{ x: ["-50%", "0%"] }}
              transition={{ repeat: Infinity, ease: "linear", duration: 35 }}
            >
              {[...ROW2, ...ROW2].map((inst, i) => (
                <div key={i} className="flex items-center gap-3 px-6 py-4 bg-bg border border-rule/50 rounded-full shadow-lg shadow-black/20 hover:border-brand/50 transition-colors cursor-default">
                  <Building className="w-4 h-4 text-brand/70" />
                  <span className="font-mono text-xs sm:text-sm text-fg/80 uppercase tracking-wide">{inst}</span>
                </div>
              ))}
            </motion.div>

            {/* Third Row */}
            <motion.div 
              className="flex gap-4 sm:gap-6 w-max ml-[-50px]"
              animate={{ x: ["0%", "-50%"] }}
              transition={{ repeat: Infinity, ease: "linear", duration: 40 }}
            >
              {[...ROW3, ...ROW3].map((inst, i) => (
                <div key={i} className="flex items-center gap-3 px-6 py-4 bg-bg border border-rule/50 rounded-full shadow-lg shadow-black/20 hover:border-brand/50 transition-colors cursor-default">
                  <MapPin className="w-4 h-4 text-brand/70" />
                  <span className="font-mono text-xs sm:text-sm text-fg/80 uppercase tracking-wide">{inst}</span>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
