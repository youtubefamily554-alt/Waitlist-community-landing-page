import { useEffect, useState } from 'react';
import { doc, onSnapshot, setDoc, updateDoc, increment, getDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';

export function useClickCounter(statId: string) {
  const [count, setCount] = useState<number | null>(null);

  useEffect(() => {
    const docRef = doc(db, 'stats', statId);

    // Initialize document if it doesn't exist
    getDoc(docRef).then((snap) => {
      if (!snap.exists()) {
        setDoc(docRef, { clicks: 0 }, { merge: true });
      }
    });

    const unsubscribe = onSnapshot(docRef, (snap) => {
      if (snap.exists()) {
        setCount(snap.data().clicks);
      }
    });

    return () => unsubscribe();
  }, [statId]);

  const recordClick = async () => {
    const docRef = doc(db, 'stats', statId);
    try {
      await updateDoc(docRef, {
        clicks: increment(1)
      });
    } catch (e) {
      // Fallback if doc doesn't exist somehow
      await setDoc(docRef, { clicks: 1 }, { merge: true });
    }
  };

  return { count, recordClick };
}
