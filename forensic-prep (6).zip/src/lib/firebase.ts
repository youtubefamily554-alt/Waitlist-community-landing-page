import { initializeApp } from "firebase/app";
import { getFirestore, initializeFirestore } from "firebase/firestore";
import firebaseConfigData from "../../firebase-applet-config.json";

// We extract the actual needed properties because firebase-applet-config.json has extra properties
const firebaseConfig = {
  apiKey: firebaseConfigData.apiKey,
  authDomain: firebaseConfigData.authDomain,
  projectId: firebaseConfigData.projectId,
  storageBucket: firebaseConfigData.storageBucket,
  messagingSenderId: firebaseConfigData.messagingSenderId,
  appId: firebaseConfigData.appId,
  measurementId: firebaseConfigData.measurementId,
};

const app = initializeApp(firebaseConfig);
const db = initializeFirestore(app, {}, firebaseConfigData.firestoreDatabaseId);

export { app, db };
